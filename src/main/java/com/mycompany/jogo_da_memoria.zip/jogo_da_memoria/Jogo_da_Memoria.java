/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.jogo_da_memoria;

/**
 *
 * @author arthu
 */
 
public class Jogo_da_Memoria {

    public static void main(String[] args) {
        
        new Tela_inicial().setVisible(true);
        
    }
}
